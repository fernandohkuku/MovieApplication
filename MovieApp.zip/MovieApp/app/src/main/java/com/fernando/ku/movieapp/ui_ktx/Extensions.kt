package com.fernando.ku.movieapp.ui_ktx

fun emptyString() = ""